package com.capgemini.anurag.transaction.Controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.anurag.transaction.dto.Transaction;
import com.capgemini.anurag.transaction.service.TransactionService;
@RestController 
public class CreditController {
	@Autowired
	TransactionService transactionService;
	public void setTransactionService(TransactionService transactionService)
	{
		this.transactionService=transactionService;
	}
	@GetMapping(value="/creditusingslip/accno/{account_No}/amount/{amount}")
    public void creditUsingSlip(@PathVariable long account_No,@PathVariable double amount)
    {
		transactionService.creditUsingSlip(account_No, amount);
    }
	@GetMapping("/creditusingcheque/{accountNo}/{amount}/{accFrom}/{bankname}/{ifsc}/{issueddate}")
	public void creditUsingCheque(@PathVariable int cheque_id,@PathVariable long accountNo,@PathVariable double amount,@PathVariable long accFrom,@PathVariable String bankname,@PathVariable String ifsc,@PathVariable String issueddate) throws ParseException
	{
		Date d = new SimpleDateFormat("dd-mm-yyyy").parse(issueddate);
		transactionService.creditUsingCheque(cheque_id,accountNo, amount, accFrom, bankname, ifsc, d);
	}
}






