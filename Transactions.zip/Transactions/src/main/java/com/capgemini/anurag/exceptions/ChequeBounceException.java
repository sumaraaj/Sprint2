package com.capgemini.anurag.exceptions;

@SuppressWarnings("serial")
public class ChequeBounceException extends Exception {
	public ChequeBounceException()
	{
		super();
	}
	public ChequeBounceException(String message)
	{
		super(message);
	}
}
