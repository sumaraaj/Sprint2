package com.capgemini.anurag.transaction.Controller;



import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.anurag.transaction.dto.Cheque;
import com.capgemini.anurag.transaction.dto.Transaction;
import com.capgemini.anurag.transaction.service.TransactionService;
@RestController
@CrossOrigin
public class CreditController {
	@Autowired
	TransactionService transactionService;
	public void setTransactionService(TransactionService transactionService)
	{
		this.transactionService=transactionService;
	}
	@ExceptionHandler(value=NoSuchElementException.class)
	public ResponseEntity<String> accountNotFoundException()
	{
		return new ResponseEntity<>("Account not found",HttpStatus.NOT_FOUND);
	}
	@GetMapping(value="/creditusingslip/accno/{account_No}/amount/{amount}")
    public ResponseEntity<String> creditUsingSlip(@PathVariable long account_No,@PathVariable double amount)
    {
    	boolean b = transactionService.creditUsingSlip(account_No, amount);
    	if(b==true)
    		return new ResponseEntity<>("Successful",HttpStatus.OK);
    	else
    		return new ResponseEntity<>("Failed",HttpStatus.NOT_ACCEPTABLE);
    }
	@PostMapping(value="/creditusingcheque/accountno/{accountNo}",consumes= {"application/json","application/xml"})
	public ResponseEntity<String> creditUsingCheque(@PathVariable long accountNo,@RequestBody() Cheque cheque) 
	{
		boolean b = transactionService.creditUsingCheque(accountNo,cheque);
		if(b==true)
    		return new ResponseEntity<>("Successful",HttpStatus.OK);
    	else
    		return new ResponseEntity<>("Failed",HttpStatus.NOT_ACCEPTABLE);
	}
}






