import { Component } from '@angular/core';
@Component({
    selector:'',
    template:'<h1>404 Page Not Found</h1>',
    styles:['h1{text-align:center;color:red}']
})
export class PageNotFoundComponent{}