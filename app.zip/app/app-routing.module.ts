import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreditComponent } from './credit/credit-component';
import { CreditChequeComponent } from './credit/creditcheque-component'
import { PageNotFoundComponent } from './app.page-not-found.component';
const routes: Routes = [
  {path:'',redirectTo:'/creditUsingSlip',pathMatch:'full'},
{path:'creditSlip',component:CreditComponent},
{path:'creditCheque',component:CreditChequeComponent},
{path:'**',component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
