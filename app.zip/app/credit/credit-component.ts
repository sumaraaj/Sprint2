import { Component,OnInit } from '@angular/core';
import { CreditService } from './credit-service';
import { Transaction } from './transaction';
@Component({
    selector:'credit-slip',
templateUrl:'./credit-component.html'
})
export class CreditComponent implements OnInit
{
transaction:Transaction=new Transaction(0,0,'',0,0,'');
public constructor(private creditService:CreditService){}
public creditUsingSlip():void
{
    this.creditService.creditUsingSlip(this.transaction).subscribe();
}
ngOnInit()
{
    
}
}