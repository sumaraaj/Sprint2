import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { CreditComponent } from './credit-component';
import { CreditChequeComponent } from './creditcheque-component';
import { CreditService } from './credit-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
@NgModule({
    declarations: [
        CreditComponent,CreditChequeComponent
    ],
    imports: [
        HttpClientModule,FormsModule,CommonModule 
    ],
    providers: [ CreditService ],
    exports: [ CreditComponent,CreditChequeComponent ]
})
export class CreditModule
{
    
}