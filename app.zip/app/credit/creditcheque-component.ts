import { Component,OnInit } from '@angular/core';
import { CreditService } from './credit-service';
import { Cheque } from './cheque';
@Component({
    selector:'credit-slip',
templateUrl:'./credit-cheque.html'
})
export class CreditChequeComponent implements OnInit
{
cheque:Cheque=new Cheque(0,0,'','',0,'','');
public constructor(private creditService:CreditService){}
public creditUsingCheque():void
{
    this.creditService.creditUsingCheque(this.cheque).subscribe();
}
ngOnInit()
{
}
}