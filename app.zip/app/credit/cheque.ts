export class Cheque
{
    cheque_id:number;
    account_id:number;
    bank_name:String;
    ifsc:String;
    amount:number;
    issued_date:Date;
    status:String;
    public constructor(cheque_id:number,account_id:number,bank_name:String,ifsc:String,amount:number,issued_date:Date,status:String)
    {
        this.cheque_id=cheque_id;
        this.account_id=account_id;
        this.bank_name=bank_name;
        this.ifsc=ifsc;
        this.amount=amount;
        this.issued_date=issued_date;
        this.status=status;
    }
}