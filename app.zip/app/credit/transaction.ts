import { Cheque } from './cheque';

export class Transaction
{
    trans_id:number;
    account_id:number;
    type:String;
    amount:number;
    dateoftrans:Date;
    public constructor(trans_id:number,account_id:number,type:String,amount:number,dateoftrans:Date)
    {
        this.trans_id=trans_id;
        this.account_id=account_id;
        this.type=type;
        this.amount=amount;
        this.dateoftrans=dateoftrans;
    }
}