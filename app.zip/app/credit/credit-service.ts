import { HttpClient } from '@angular/common/http';
import { Transaction } from './transaction';
import { Cheque } from './cheque';
import { Injectable } from '@angular/core';
@Injectable({
    providedIn:'root'
})
export class CreditService
{
    public constructor(private httpClient:HttpClient){}
    public creditUsingSlip(transaction:Transaction):any
    {
        return this.httpClient.put<any>('http://localhost:8091/creditUsingSlip',transaction);
    }
    public creditUsingCheque(cheque:Cheque):any{
        return this.httpClient.put<any>('http://localhost:8091/creditUsingSlip',cheque);
    }
}